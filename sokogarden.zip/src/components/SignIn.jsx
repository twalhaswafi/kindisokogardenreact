import React from 'react'
import { Link } from 'react-router-dom'

import { useState } from 'react';
import axios from "axios";
import { useNavigate } from 'react-router-dom'


const SignIn = () => {
  const[email,setEmail]=useState("");
  const[password,setPassword]=useState("");
  const[success,setSuccess]=useState("");
  const[loading,setLoading]=useState("");
  const[error,setError]=useState("");
  const navigate=useNavigate()

  const submit=async(e)=>{

    e.preventDefault()
    setLoading("please wait as we log you in")

    try{
      const data=new FormData()

      data.append("email",email)
      data.append("password",password)

      const responce=await axios.post("https://modcom2.pythonanywhere.com/api/signin",data)
      console.log(responce)

      setLoading("")
      setSuccess(responce.data.message)

      if(responce.data.user){

        navigate("/")


      }

      else{
        setError(responce.data.message)
      }

      



    }catch (error) {
      setLoading("")
      setError(error.message)
    }


  }


  

  return (
    <div className='row justify-content-center mt-4'> 

    <div className='col-md-6 p-4 card shadow'>
       {/* <h1>Welcome to SignIn page</h1>  */}
       <h2>Sign In</h2>

       <form action="" onSubmit={submit}>

        <p className='text-warning'>{loading}</p>
        <p className='text-success'>{success}</p>
        <p className='text-error'>{error}</p>
        <input type="email" placeholder='enter email' className='form-control'required onChange={(e)=>setEmail(e.target.value)} value={email}/>
        <br />
        <br />
        <input type="password" placeholder='enter password' className='form-control'required onChange={(e)=>setPassword(e.target.value)} value={password}/>
        <br />
        <br />

        <button type='submit' className='btn btn-primary '>SignIn</button>
       </form>

       Dont have an account?please<Link to='/signin' >Sign Up</Link>
    </div>
    </div>
  )
}

export default SignIn


