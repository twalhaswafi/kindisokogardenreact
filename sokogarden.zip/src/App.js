
import './App.css';

import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import axios from 'axios';

 

import { BrowserRouter as Router, Route, Routes, Link} from "react-router-dom";
import SignUp from './components/SignUp';
import SignIn from './components/SignIn';
import AddProducts from './components/AddProducts';
import GetProducts from './components/GetProducts';
import MpesaPayment from './components/MpesaPayment';

function App() {
  return (
    <Router>
    <div className="App">
      <header className="App-header">
       <h1>SokoGarden-Buy and sell online</h1>
      </header>
      {/* <nav>
        <Link to='/SignIn'className='navlinks'>SignIn</Link>
        <Link to='/SignUp'className='navlinks'>SignUp</Link>
        <Link to='/GetProducts'className='navlinks'>GetProducts</Link>
        <Link to='/AddProducts'className='navlinls'>AddProducts</Link>
      </nav> */}
      <Routes>
        
      <Route path='/signup' element={<SignUp/>}/>
      <Route path='/signin' element={<SignIn/>}/>
      <Route path='/addproducts' element={<AddProducts/>}/>
      <Route path='/' element={<GetProducts/>}/>
      <Route path='/mpesapayment' element={<MpesaPayment/>}/>
      </Routes>

    </div>
    </Router>
  );
}

export default App;

// sokogarden endpoint
// https://twalhaswafi.pythonanywhere.com/api/mpesa_payment
// https://twalhaswafi.pythonanywhere.com/api/add_product
// https://twalhaswafi.pythonanywhere.com/api/get_products_details
// https://twalhaswafi.pythonanywhere.com/api/signin
// https://twalhaswafi.pythonanywhere.com/api/signup